import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import "./Home.css";

const translations = {
  en: {
    hero_eyebrow: "Private Collection · 20 Villas · Marrakech",
    hero_subtitle: "By Arabesque Residences",
    hero_tagline: '"Where the Atlas meets the art of living — a private sanctuary shaped by silence, light, and the ancient wisdom of the olive."',
    stat_villas: "Private Villas", stat_land: "Ha · Domain", stat_delivery: "Delivery",
    hero_cta: "Unlock the Exclusive Dossier", hero_scroll: "Discover",
    about_label: "The Project",
    about_title: "A Rare Estate Born of Light and Land",
    about_text: "Zaytoun is a private residential domain of twenty villas set within 4.4 hectares of olive groves on the prestigious Route de Tahannouat — where Marrakech opens to the Atlas Mountains. A development that redefines what it means to live well in Morocco.",
    fact_villas: "Private Villas", fact_wellness: "Wellness Center", fact_typologies: "Villa Typologies", fact_suites: "Suites per Villa",
    dest_label: "The Destination",
    dest_title: "Marrakech — Africa's Most Coveted Address",
    dest_text: "An imperial city where cultural heritage, natural beauty, and investment opportunity converge. Marrakech continues to attract the world's most discerning buyers — with rising property values, strong rental yields, and an international lifestyle unlike anywhere else on the continent.",
    dest_golf: "Golf & Leisure", dest_golf_text: "Three world-class golf courses within 5 minutes, including the legendary Amelkis Golf Resort.",
    dest_air: "International Connectivity", dest_air_text: "Menara Airport — 20 minutes. Direct flights to Paris, London, Dubai, and 50+ destinations.",
    dest_nature: "Atlas Mountains", dest_nature_text: "Panoramic views of the snow-capped Atlas from every villa. A horizon that belongs only to you.",
    dist_golf: "Golf", dist_medina: "Medina", dist_airport: "Airport",
    dist_hivernage: "Hivernage",
    atlas_caption: "Atlas Mountains — view from Zaytoun",
    invest_label: "Why Invest in Marrakech",
    invest_title: "A Market That Consistently Delivers",
    inv_stat1_num: "+8%", inv_stat1_label: "Annual Price Growth", inv_stat1_text: "Luxury property values in Marrakech have grown consistently above regional averages.",
    inv_stat2_num: "7–10%", inv_stat2_label: "Gross Rental Yield", inv_stat2_text: "High-end villas command premium short-term rental rates, driven by year-round tourism demand.",
    inv_stat3_num: "5M+", inv_stat3_label: "Annual Tourists", inv_stat3_text: "Morocco's #1 tourist destination, with visitor numbers recovering strongly, with over 5 million annual visitors.",
    inv_stat4_num: "100%", inv_stat4_label: "Foreign Ownership", inv_stat4_text: "Morocco fully permits foreign freehold ownership with free repatriation of capital and rental income.",
    map_label: "Location", map_open: "↗ Open in Maps",
    loc_label: "Our Location",
    loc_golf_label: "Golf — 5 min", loc_golf_title: "World-Class Golf on Your Doorstep", loc_golf_text: "Three championship courses lie within minutes — Amelkis Golf Club, Noria Golf Club, and Argan Golf Resort. Access to premier greens is effortless from Route de Tahannouat.",
    loc_hiv_label: "Hivernage & Medina — 20 min", loc_hiv_title: "The Best of Marrakech Within Reach", loc_hiv_text: "Hivernage, Marrakech's luxury district, is home to the finest hotels, restaurants, and boutiques. Jamaa el-Fna and the historic Medina are equally accessible.",
    loc_air_label: "Menara Airport — 20 min", loc_air_title: "Connected to Europe, the Gulf & Beyond", loc_air_text: "Marrakech Menara Airport is 20 minutes away, offering direct connections to Paris, London, Madrid, Dubai and 50+ international destinations.",
    well_label: "Healthy Living",
    well_title: "A Sanctuary Designed for Well-Being",
    well_text: "At Zaytoun, luxury is measured not in square metres, but in the quality of each morning, each breath, each moment of stillness. An 800m² wellness center open to all, with privileged priority access for residents.",
    wf1_title: "Spa & Hammam", wf1_text: "Traditional Moroccan hammam, treatment rooms, and curated spa therapies drawing on Argan and Rose traditions.",
    wf2_title: "Fitness & Movement", wf2_text: "State-of-the-art fitness studio, yoga pavilion, padel courts, and walking trails through the olive groves.",
    wf3_title: "Gardens & Nature", wf3_text: "Meditation gardens, water features, and 4.4 hectares of landscaped grounds with centuries-old olive trees.",
    gate_label: "Exclusive Access",
    gate_title: "Unlock the Complete Dossier",
    gate_subtitle: "Floor plans, starting price, payment schedule, and delivery timeline — reserved for qualified acquirers. Your information remains strictly confidential.",
    lock1: "Villa Arbea Floor Plans", lock2: "Villa Ziria Floor Plans", lock3: "Starting Price", lock4: "Payment Plan", lock5: "Handover Date",
    form_firstname: "First Name", form_firstname_ph: "Jean",
    form_lastname: "Last Name", form_lastname_ph: "Dupont",
    form_email: "Email Address", form_email_ph: "jean@example.com",
    form_phone: "Phone / WhatsApp", form_phone_ph: "+33 6 00 00 00 00",
    form_country: "Country of Residence", form_country_ph: "Select country",
    form_intent: "Purchase Intent", form_intent_ph: "Select...",
    intent1: "Primary Residence", intent2: "Investment / Rental", intent3: "Secondary Residence", intent4: "Exploring Options",
    gate_submit: "Access the Exclusive Dossier →",
    gate_privacy: "Your information is confidential and will never be shared with third parties.",
    success_title: "Welcome to Zaytoun",
    success_text: "Your exclusive dossier is now unlocked. Scroll down to discover the complete details — floor plans, pricing, and investment terms.",
    success_scroll: "Scroll to explore",
    dossier_unlocked: "Dossier Unlocked",
    dossier_label: "Complete Investment Dossier",
    dossier_title: "Everything You Need to Decide",
    dossier_text: "Floor plans, pricing, payment schedule, delivery timeline, and technical specifications.",
    tab_villas: "The Villas", tab_interiors: "Interiors", tab_plans: "Floor Plans", tab_pricing: "Pricing & Payment", tab_finishes: "Finishes & Materials", tab_services: "Services",
    villa_arbea: "Villa Arbea", villa_ziria: "Villa Ziria",
    spec_suites: "Suites", spec_levels: "Levels", spec_pool: "Infinity Pool", spec_parking: "Parking",
    arbea_desc: "A configuration that prioritises horizontal space and garden views — 5 suites including Junior and Master configurations. Ground-floor living extends seamlessly to pool terrace and landscaped gardens.",
    ziria_desc: "A vertical composition across two floors with dramatic double-height volumes — rooftop terrace and upper-level master suite offer panoramic Atlas views.",
    plan_arbea_title: "Villa Arbea — Ground Floor & First Floor",
    plan_ziria_title: "Villa Ziria — Ground Floor & First Floor",
    plan_mp_label: "Master Plan", plan_mp_title: "Zaytoun Marrakech — Site Plan",
    plan_arbea_label: "Type A — Villa Arbea", plan_ziria_label: "Type B — Villa Ziria",
    plan_zoom_hint: "Click image to zoom",
    plan_note_label: "Floor Plan",
    plan_note: "Architectural drawings will be displayed here.\nPlease contact our sales team for the detailed PDF plan package.",
    plan_contact_note: 'To receive the complete architectural PDF package, contact us at <a href="mailto:sales@arabesque.life" style="color:#C4765A;">sales@arabesque.life</a>',
    price_from: "Starting From",
    price_note: "Subject to villa configuration and lot selection • VAT applicable per Moroccan law",
    payment_title: "Payment Plan",
    pay1: "At Reservation", pay4: "At Handover",
    handover_title: "Delivery Timeline",
    handover_text: "Construction commenced April 2026. Phased delivery programme — Phase 1 (pilot villa) leads, followed by progressive delivery of all 20 residences.",
    handover_label: "Estimated Delivery",
    fin_floor: "Flooring", fin_carp: "Carpentry", fin_struct: "Structure", fin_tech: "Technology & Comfort", fin_out: "Outdoors",
    fin_f1: "Matte cream microcement with mineral finish & water-repellent protection",
    fin_f2: "Traditional Zellige tiles in key living areas",
    fin_f3: "Solid oak parquet in suites",
    fin_f4: "Terraces in Taza stone bejmat",
    fin_f5: "Pool deck in Taza stone",
    fin_c1: "Matte black aluminium exterior frames", fin_c2: "Double thermal glazing throughout",
    fin_c3: "Full-height pivot entrance door in oak or walnut",
    fin_c4: "Custom wardrobes with integrated lighting & push-to-open",
    fin_c5: "High-end custom kitchen — Bosch or equivalent appliances",
    fin_c6: "Matte lacquered fronts with quartzite countertops",
    fin_s1: "Reinforced concrete — earthquake-resistant standards",
    fin_s2: "Double-layer bitumen waterproofing on roof & terraces",
    fin_s3: "Thermal insulation for walls and roof",
    fin_s4: "False ceilings with indirect LED lighting",
    fin_s5: "Artisanal plaster details in selected areas",
    fin_s6: "Elevator shaft provision (buyer installation)",
    fin_t1: "Ducted heating & cooling system",
    fin_t2: "Smart home pre-installation — lighting, AC, blinds",
    fin_t3: "Solar water heater with buffer tank",
    fin_t4: "Alarm system & video surveillance",
    fin_t5: "Fiber optic internet in every room",
    fin_o1: "Private infinity pool", fin_o2: "Landscaping: olive, palm & orange trees",
    fin_o3: "Landscape lighting & full irrigation system",
    fin_o4: "Motorized gate with remote control",
    svc1_title: "Post-Handover Maintenance", svc1_text: "Full property maintenance managed by R+E Services — ensuring your villa remains in pristine condition year-round, whether in residence or not.",
    svc2_title: "Short-Term Rental Management", svc2_text: "Professional rental management maximising your villa's income potential on platforms like Airbnb, Booking.com, and through luxury channel partners.",
    svc3_title: "Optional Furniture Package", svc3_text: "Full house furnishing by our expert interior designer team — a curated, turnkey package that reflects the Zaytoun aesthetic from day one.",
    svc4_title: "Legal & Foreign Ownership Support", svc4_text: "Dedicated legal guidance throughout the acquisition process under Moroccan law (Loi 44-00 VEFA). Foreign ownership fully supported.",
    cta_title: "Ready to Secure Your Villa?",
    cta_text: "Our sales team is available for private consultations — in Marrakech, by video call, or at your convenience.",
    cta_call: "+212 777 47 47 47", cta_email: "sales@arabesque.life",
    footer_tagline: '"Life here slows to the rhythm of olive groves and mountain light."',
    footer_nav: "Navigation", footer_contact: "Contact",
    nav_home: "Home", nav_project: "The Project", nav_dest: "Marrakech", nav_dossier: "Exclusive Dossier",
    disclaimer: "The information contained herein is for general guidance only and does not constitute an offer, solicitation, representation, or warranty of any kind. All descriptions, dimensions, specifications, and other details are provided in good faith and are subject to change without notice. Prospective buyers should consult their legal, financial, and real estate advisors. All rights reserved.",
    int_label: "Interior Renders",
    int_title: "A Refined Art of Living",
    int_subtitle: "Each villa is designed around the experience of living — intimate spaces that open to gardens and light, with artisanal finishes drawn from Moroccan craft tradition.",
    int_salon: "Living Room — Fireplace & Garden View",
    int_villa_a: "Villa Arbea",
    int_salon_desc: "Moroccan brass, bejmat zellige, and artisan plaster — the salon opens through full-height glazing onto the private terrace and pool.",
    int_shower: "Master Suite Bathroom",
    int_villa_ab: "All Villas",
    int_shower_desc: "Walk-in rain shower with mosaic tile accent wall and floor-to-ceiling glazing onto a private garden. Brushed black fittings throughout.",
    int_vanity: "Double Vanity — Tadelakt & Stone",
    int_vanity_desc: "Floating double basin in tadelakt — Morocco's traditional waterproof lime plaster — with integrated storage and artisanal ceramics.",
    int_bedroom: "Master Suite — Bedroom",
    int_bedroom_desc: "Generous master suite with floor-to-ceiling openings, tadelakt walls and bespoke joinery. Each suite is conceived as a private retreat within the villa.",
    int_note_label: "Finishes & Materials",
    int_note_text: "All renders show the standard specification. Premium upgrade packages available — see the Finishes & Materials tab for full details.",
  },

  ar: {
    hero_eyebrow: "مجموعة حصرية · 20 فيلا فاخرة · مراكش",
    hero_subtitle: "من أرابيسك ريزيدنسز",
    hero_tagline: "بعض الأماكن لا تُشترى — بل تُختار. زيتون هو ذلك القرار الذي يظل معك طوال العمر.",
    stat_villas: "فيلا خاصة", stat_land: "هكتار · المجمع", stat_delivery: "التسليم",
    hero_cta: "الوصول إلى الملف الحصري", hero_scroll: "اكتشف",
    about_label: "المشروع",
    about_title: "لأن بعض اللحظات تستحق مكانًا يليق بها",
    about_text: "تخيّل أن تستيقظ كل يوم على إطلالة الأطلس، وأن تمشي على حجارة بجماط تحت شمس مراكش، وأن يكون بيتك ملاذًا لا مجرد عنوان. زيتون هو عشرون فيلا على 4.4 هكتار من بساتين الزيتون — صُمِّم لمن يؤمن أن الحياة الحقيقية تبدأ خارج المدينة.",
    fact_villas: "فيلا خاصة", fact_wellness: "مركز الصحة والعافية", fact_typologies: "نماذج الفلل", fact_suites: "جناح لكل فيلا",
    dest_label: "الوجهة",
    dest_title: "مراكش — المدينة التي تسكن فيك قبل أن تسكن فيها",
    dest_text: "مراكش مدينة من اخترها مرة واحدة، اختارته إلى الأبد. ليس لأنها جميلة فحسب — بل لأنها تمنحك شيئًا لا تجده في دبي ولا باريس: روحًا حقيقية. ومع عوائد إيجارية تصل إلى 10% وقيم عقارية في ارتفاع مستمر، قرارك هنا ليس عاطفيًا فقط — بل هو الأذكى ماليًا.",
    dest_golf: "الغولف والترفيه", dest_golf_text: "ثلاثة ملاعب غولف عالمية المستوى على بُعد 5 دقائق، منها ملعب أميلكيس الأسطوري.",
    dest_air: "الاتصال الدولي", dest_air_text: "مطار المنارة — 20 دقيقة. رحلات مباشرة إلى باريس ولندن ودبي وأكثر من 50 وجهة.",
    dest_nature: "جبال الأطلس", dest_nature_text: "مناظر بانورامية على الأطلس المكسو بالثلوج من كل فيلا. أفق يخصك وحدك.",
    dist_golf: "الغولف", dist_medina: "المدينة العتيقة", dist_airport: "المطار",
    dist_hivernage: "هيفيرناج",
    atlas_caption: "هذا ما يراه ساكنو زيتون كل صباح",
    invest_label: "لماذا مراكش؟ لأن الأرقام لا تكذب",
    invest_title: "المال الذكي يختار مراكش — وهذا ما تقوله الأرقام",
    inv_stat1_num: "+8%", inv_stat1_label: "النمو السنوي للأسعار", inv_stat1_text: "قيم الفلل الفاخرة في مراكش تتصاعد باستمرار — والمبكر دائمًا الرابح الأكبر.",
    inv_stat2_num: "7–10%", inv_stat2_label: "العائد الإيجاري الإجمالي", inv_stat2_text: "عوائد إيجارية تتجاوز أغلب الأسواق العالمية — لأن الطلب السياحي لا يتوقف.",
    inv_stat3_num: "+5م", inv_stat3_label: "سائح سنوياً", inv_stat3_text: "خمسة ملايين زائر سنويًا يختارون مراكش — وكل زيارة هي فرصة إيجارية لفيلتك.",
    inv_stat4_num: "100%", inv_stat4_label: "تملك أجنبي حر", inv_stat4_text: "المغرب يُتيح التملك الأجنبي الكامل مع حرية تحويل رأس المال والعائدات — بدون قيود.",
    map_label: "الموقع", map_open: "↗ فتح في الخرائط",
    loc_label: "موقعنا",
    loc_golf_label: "غولف — 5 دقائق", loc_golf_title: "ثلاثة ملاعب. خمس دقائق. حياة مختلفة.", loc_golf_text: "ثلاثة ملاعب بطولية على بُعد دقائق — نادي أميلكيس، نادي نوريا، ومنتجع أرغان. الوصول إلى أفضل الملاعب سهل من طريق تحناوت.",
    loc_hiv_label: "أرقى أحياء مراكش — 20 دقيقة", loc_hiv_title: "من الهدوء إلى قلب المدينة — في عشرين دقيقة فقط", loc_hiv_text: "هيفيرناج، حي الرفاهية في مراكش، يضم أرقى الفنادق والمطاعم والمتاجر. جامع الفنا والمدينة التاريخية في متناول يدك.",
    loc_air_label: "مطار المنارة — 20 دقيقة", loc_air_title: "العالم على بُعد ساعات — ومراكش هي عودتك إلى البيت", loc_air_text: "مطار مراكش المنارة على بُعد 20 دقيقة، مع رحلات مباشرة إلى باريس ولندن ومدريد ودبي وأكثر من 50 وجهة دولية.",
    well_label: "أسلوب حياة صحي",
    well_title: "أخيرًا، مكان يُعيدك إلى نفسك",
    well_text: "في زيتون لا يقولون لك كم متر مربع فيلتك — يسألونك كيف تريد أن تستيقظ غدًا. مركز عافية بمساحة 800م² صُمِّم ليجعلك تشعر بالفرق منذ اليوم الأول. مفتوح للجميع — وأنت كساكن في زيتون، دائمًا الأول.",
    wf1_title: "الحمام المغربي — تراث تُعيشه لا تُشاهده", wf1_text: "حمام مغربي تقليدي وغرف علاجية وجلسات سبا تستلهم من تقاليد الأرغان والورد.",
    wf2_title: "جسدك يستحق أفضل بداية لكل يوم", wf2_text: "استوديو لياقة متطور وجناح يوغا وملاعب بادل ومسارات للمشي عبر بساتين الزيتون.",
    wf3_title: "الطبيعة هنا ليست خلفية — هي البيت", wf3_text: "حدائق تأمل ومجاري مياه و4.4 هكتار من المساحات الخضراء مع أشجار زيتون معمّرة.",
    gate_label: "وصول حصري",
    gate_title: "20 فيلا فقط. بعضها اختير بالفعل.",
    gate_subtitle: "المخططات، السعر، جدول الدفع وموعد التسليم — لا تُشارَك علنًا. سجّل الآن وسيتواصل معك فريقنا خلال 24 ساعة.",
    lock1: "مخططات فيلا أربع", lock2: "مخططات فيلا زيريا", lock3: "السعر الابتدائي", lock4: "خطة الدفع", lock5: "موعد التسليم",
    form_firstname: "الاسم الأول", form_firstname_ph: "محمد",
    form_lastname: "اسم العائلة", form_lastname_ph: "العلوي",
    form_email: "البريد الإلكتروني", form_email_ph: "example@domain.com",
    form_phone: "الهاتف / واتساب", form_phone_ph: "+212 6 00 00 00 00",
    form_country: "بلد الإقامة", form_country_ph: "اختر البلد",
    form_intent: "نية الشراء", form_intent_ph: "اختر...",
    intent1: "إقامة رئيسية", intent2: "استثمار / إيجار", intent3: "إقامة ثانوية", intent4: "استكشاف الخيارات",
    gate_submit: "الوصول إلى الملف الحصري →",
    gate_privacy: "معلوماتك سرية ولن تُشارَك مع أي طرف ثالث.",
    success_title: "أهلًا بك في دائرة من يفكرون بشكل مختلف",
    success_text: "ملفك الحصري جاهز. اكتشف الآن ما يجعل زيتون مختلفًا — من المخططات إلى خطة الدفع المرنة وموعد استلامك.",
    success_scroll: "مرّر للاستكشاف",
    dossier_unlocked: "تم فتح الملف",
    dossier_label: "ملف الاستثمار الكامل",
    dossier_title: "كل التفاصيل — لا أسرار، لا مفاجآت",
    dossier_text: "المخططات المعمارية والتسعير وجدول الدفع وموعد التسليم والمواصفات التقنية.",
    tab_villas: "الفلل", tab_interiors: "التصميم الداخلي", tab_plans: "المخططات", tab_pricing: "الأسعار والدفع", tab_finishes: "التشطيبات والمواد", tab_services: "الخدمات",
    villa_arbea: "فيلا أربع", villa_ziria: "فيلا زيريا",
    spec_suites: "أجنحة", spec_levels: "طوابق", spec_pool: "مسبح لانهائي", spec_parking: "مواقف",
    arbea_desc: "فيلا أربع لمن اختار أن تكون حياته كلها على مستوى واحد — خمسة أجنحة تنساب نحو الحديقة الخاصة والمسبح اللانهائي. لا درج، لا حواجز، فقط أنت والفضاء والضوء.",
    ziria_desc: "فيلا زيريا لمن يريد أن يرى مراكش من فوق — أربعة أجنحة على طابقين، وتراس سطحي تحتسي عليه قهوتك الصباحية والأطلس أمامك مباشرة. بعض الإطلالات لا تُنسى.",
    plan_mp_label: "المخطط العام", plan_mp_title: "زيتون مراكش — مخطط الموقع",
    plan_arbea_label: "النوع A — فيلا أربع", plan_ziria_label: "النوع B — فيلا زيريا",
    plan_zoom_hint: "انقر للتكبير",
    plan_arbea_title: "فيلا أربع — الطابق الأرضي والطابق الأول",
    plan_ziria_title: "فيلا زيريا — الطابق الأرضي والطابق الأول",
    plan_note_label: "المخطط المعماري",
    plan_note: "سيتم عرض المخططات المعمارية هنا.\nتواصل مع فريق المبيعات للحصول على حزمة PDF الكاملة.",
    plan_contact_note: 'للحصول على حزمة المخططات المعمارية كاملةً، تواصل معنا على <a href="mailto:sales@arabesque.life" style="color:#C4765A;">sales@arabesque.life</a>',
    price_from: "تبدأ الاستثمارات من",
    price_note: "حسب تكوين الفيلا واختيار القطعة • TVA وفق القانون المغربي",
    payment_title: "خطة دفع صُمِّمت لراحتك",
    pay1: "عند الحجز", pay4: "عند التسليم",
    handover_title: "موعد التسليم محفور في الحجر",
    handover_text: "انطلق البناء في أبريل 2026 وفق جدول واضح ومُلتزم به. لأن الوعد بدون موعد ليس وعدًا — وزيتون يحترم وقتك ومالك.",
    handover_label: "التسليم المتوقع",
    fin_floor: "الأرضيات", fin_carp: "النجارة", fin_struct: "الهيكل الإنشائي", fin_tech: "التكنولوجيا والراحة", fin_out: "الخارج",
    fin_f1: "ميكروسيمنت كريمي مط بمعالجة مقاومة للماء والزيوت",
    fin_f2: "بلاط زليج تقليدي في المساحات المعيشية الرئيسية",
    fin_f3: "باركيه صلب من خشب البلوط في الأجنحة",
    fin_f4: "التراسات بحجر بجماط التازي",
    fin_f5: "أرضية حمام السباحة بحجر تازة",
    fin_c1: "إطارات خارجية من الألومنيوم الأسود المطفي",
    fin_c2: "زجاج مزدوج حراري في جميع الأنحاء",
    fin_c3: "باب مدخل محوري بارتفاع كامل من خشب البلوط أو الجوز",
    fin_c4: "خزائن حائطية مخصصة مع إضاءة مدمجة وفتح دفعي",
    fin_c5: "مطبخ راقٍ مخصص — أجهزة Bosch أو ما يعادلها",
    fin_c6: "واجهات مطفية مع سطح عمل من الكوارتزيت",
    fin_s1: "خرسانة مسلحة — معايير مقاومة الزلازل",
    fin_s2: "عزل مائي ثنائي الطبقة على السطح والتراسات",
    fin_s3: "عزل حراري للجدران والسقف",
    fin_s4: "أسقف مستعارة مع إضاءة LED غير مباشرة",
    fin_s5: "تفاصيل جصية حرفية في مناطق مختارة",
    fin_s6: "بئر المصعد معدة مسبقًا (تركيب المشتري)",
    fin_t1: "نظام تكييف مركزي مجاري",
    fin_t2: "تجهيز مسبق للمنزل الذكي — إضاءة وتكييف وستائر",
    fin_t3: "سخان مياه شمسي مع خزان احتياطي",
    fin_t4: "نظام إنذار ومراقبة بالكاميرات",
    fin_t5: "إنترنت بالألياف الضوئية في كل غرفة",
    fin_o1: "مسبح خاص لانهائي",
    fin_o2: "تنسيق حدائق: أشجار زيتون ونخيل وبرتقال",
    fin_o3: "إضاءة حديقة ونظام ري كامل",
    fin_o4: "بوابة آلية مع تحكم عن بعد",
    svc1_title: "بيتك في أفضل حال — حتى وأنت بعيد", svc1_text: "خدمة صيانة عقارية متكاملة تُديرها R+E Services — فيلتك تبقى في حالة مثالية طوال العام سواء كنت مقيمًا أم لا.",
    svc2_title: "عائد استثماري حتى وأنت على الشاطئ", svc2_text: "إدارة إيجارية احترافية تُعظّم دخل فيلتك عبر Airbnb وBooking.com وشركاء القنوات الفاخرة.",
    svc3_title: "فيلتك جاهزة للسكن — منذ اليوم الأول", svc3_text: "تأثيث منزل كامل من فريق المصممين الداخليين — حزمة متكاملة تعكس جمالية زيتون منذ اليوم الأول.",
    svc4_title: "استثمر بثقة — نحن نتولى كل شيء قانونيًا", svc4_text: "توجيه قانوني متخصص طوال عملية الاقتناء وفق القانون المغربي (قانون 44-00 VEFA). الملكية الأجنبية مدعومة بالكامل.",
    cta_title: "الفرصة التي تنتظرها لن تنتظرك",
    cta_text: "تحدّث مع فريقنا اليوم — استشارة خاصة وسرية، في مراكش أو من أي مكان في العالم. نحن نعرف أن قرارًا بهذا الحجم يستحق محادثة حقيقية.",
    cta_call: "+212 777 47 47 47", cta_email: "sales@arabesque.life",
    footer_tagline: "زيتون — ليس مجرد عنوان. هو الحياة التي اخترتها.",
    footer_nav: "التنقل", footer_contact: "التواصل",
    nav_home: "الرئيسية", nav_project: "المشروع", nav_dest: "مراكش", nav_dossier: "الملف الحصري",
    disclaimer: "المعلومات الواردة هنا للإرشاد العام فقط ولا تمثل عرضًا أو تمثيلًا أو ضمانًا من أي نوع. جميع الأوصاف والأبعاد والمواصفات مقدمة بحسن نية وقابلة للتغيير دون إشعار مسبق. يُنصح المشترون المحتملون باستشارة مستشاريهم القانونيين والماليين. جميع الحقوق محفوظة.",
    int_label: "التصميم الداخلي",
    int_title: "فن العيش بأسلوب راقٍ",
    int_subtitle: "كل فيلا صُمِّمت حول تجربة العيش — مساحات حميمة تفتح على الحدائق والضوء، مع تشطيبات حِرفية من التراث المغربي.",
    int_salon: "الصالون — المدفأة وإطلالة الحديقة",
    int_villa_a: "فيلا أربع",
    int_salon_desc: "نحاس مغربي، بجماط زليج، وجص حِرفي — الصالون يفتح عبر زجاج بارتفاع كامل على التراس الخاص والمسبح.",
    int_shower: "حمام الجناح الرئيسي",
    int_villa_ab: "جميع الفلل",
    int_shower_desc: "دش استحمام بجدار فسيفسائي وزجاج من الأرض إلى السقف يطل على حديقة خاصة. تركيبات سوداء مصقولة في جميع الأنحاء.",
    int_vanity: "الحمام المزدوج — تادلاكت وحجر",
    int_vanity_desc: "حوض مزدوج معلق بتادلاكت — الجص المغربي المقاوم للماء التقليدي — مع تخزين مدمج وسيراميك حِرفي.",
    int_bedroom: "الجناح الرئيسي — غرفة النوم",
    int_bedroom_desc: "جناح رئيسي واسع مع فتحات من الأرض إلى السقف وجدران تادلاكت ونجارة مخصصة. كل جناح صُمِّم كملاذ خاص داخل الفيلا.",
    int_note_label: "التشطيبات والمواد",
    int_note_text: "جميع التصاميم تعرض المواصفات القياسية. حزم ترقية متميزة متوفرة — راجع تبويب التشطيبات والمواد للتفاصيل الكاملة.",
  },
};

type Lang = "en" | "ar";

function useUtmParams() {
  return useRef({
    source: new URLSearchParams(window.location.search).get("utm_source") || "zaytoun-website",
    medium: new URLSearchParams(window.location.search).get("utm_medium") || "direct",
    campaign: new URLSearchParams(window.location.search).get("utm_campaign") || "prelaunch",
    referrer: document.referrer || "",
  }).current;
}

export default function Home() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [lang, setLang] = useState<Lang>("en");
  const [activeTab, setActiveTab] = useState("villas");
  const [dossierUnlocked, setDossierUnlocked] = useState(false);
  const [showForm, setShowForm] = useState(true);
  const utmParams = useUtmParams();
  const langBarRef = useRef<HTMLElement>(null);

  const t = translations[lang];

  const createLead = trpc.leads.create.useMutation({
    onSuccess: () => {
      setDossierUnlocked(true);
      setShowForm(false);
    },
    onError: () => {
      // Still unlock dossier so user isn't blocked
      setDossierUnlocked(true);
      setShowForm(false);
    },
  });

  const handleLangChange = useCallback((newLang: Lang) => {
    setLang(newLang);
  }, []);

  const handleTabChange = useCallback((tab: string) => {
    setActiveTab(tab);
  }, []);

  const handleGateSubmit = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      createLead.mutate({
        firstName: String(formData.get("fname") || "").trim(),
        lastName: String(formData.get("lname") || "").trim(),
        email: String(formData.get("email") || "").trim(),
        phone: String(formData.get("phone") || "").trim(),
        country: String(formData.get("country") || ""),
        intent: String(formData.get("intent") || ""),
        lang,
        utmSource: utmParams.source,
        utmMedium: utmParams.medium,
        utmCampaign: utmParams.campaign,
        referrer: utmParams.referrer,
      });
    },
    [createLead, lang, utmParams]
  );

  // Scroll effects
  useEffect(() => {
    const langBar = langBarRef.current;
    const onScroll = () => {
      if (window.scrollY > 80) langBar?.classList.add("scrolled");
      else langBar?.classList.remove("scrolled");
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [lang, dossierUnlocked]);

  useEffect(() => {
    const onScroll = () => {
      const heroContent = document.querySelector(".hero-content") as HTMLElement | null;
      if (heroContent && window.scrollY < window.innerHeight) {
        heroContent.style.transform = `translateY(${window.scrollY * 0.12}px)`;
        heroContent.style.opacity = String(1 - (window.scrollY / window.innerHeight) * 1.2);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (dossierUnlocked) {
      setTimeout(() => {
        document.getElementById("dossier")?.scrollIntoView({ behavior: "smooth" });
      }, 1300);
    }
  }, [dossierUnlocked]);

  return (
    <div className={`home-page ${lang === "ar" ? "lang-ar" : ""}`}>
      {/* ═══ LANGUAGE BAR ═══ */}
      <nav className="lang-bar" ref={langBarRef}>
        <a className="brand-logo" href="#" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
          <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_00_uxsu6j" alt="Arabesque Residences" onError={(e) => { (e.target as HTMLElement).style.display = "none"; }} />
          <span className="brand-name">Arabesque Residences</span>
        </a>
        <div className="lang-switcher">
          <button className={`lang-btn ${lang === "en" ? "active" : ""}`} onClick={() => handleLangChange("en")}>EN</button>
          <button className={`lang-btn lang-ar-btn ${lang === "ar" ? "active" : ""}`} onClick={() => handleLangChange("ar")}>عربي</button>
          {user?.role === "admin" && (
            <button className="lang-btn" onClick={() => navigate("/admin/leads")}>Admin</button>
          )}
        </div>
      </nav>

      {/* ═══ HERO ═══ */}
      <section className="hero">
        <div className="hero-bg" />
        <div className="hero-lines" />
        <div className="hero-content">
          <div className="hero-logo-wrap">
            <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_01_znu0zk" alt="Zaytoun" onError={(e) => { (e.target as HTMLElement).style.display = "none"; }} />
          </div>
          <p className="hero-eyebrow">{t.hero_eyebrow}</p>
          <div className="hero-arabic-name">زيتون</div>
          <h1 className="hero-title">Zaytoun</h1>
          <p className="hero-subtitle">{t.hero_subtitle}</p>
          <p className="hero-tagline">{t.hero_tagline}</p>
          <div className="hero-stats">
            <div className="hero-stat">
              <span className="hero-stat-num">20</span>
              <span className="hero-stat-label">{t.stat_villas}</span>
            </div>
            <div className="hero-divider" />
            <div className="hero-stat">
              <span className="hero-stat-num">4.4</span>
              <span className="hero-stat-label">{t.stat_land}</span>
            </div>
            <div className="hero-divider" />
            <div className="hero-stat">
              <span className="hero-stat-num" style={{ fontSize: 22 }}>2027–28</span>
              <span className="hero-stat-label">{t.stat_delivery}</span>
            </div>
          </div>
          <div className="hero-cta">
            <button className="btn-primary" onClick={() => document.getElementById("gate")?.scrollIntoView({ behavior: "smooth" })}>
              {t.hero_cta}
            </button>
          </div>
        </div>
        <div className="hero-scroll">
          <span>{t.hero_scroll}</span>
          <div className="scroll-line" />
        </div>
      </section>

      {/* ═══ ABOUT ═══ */}
      <section className="about-section">
        <div className="container">
          <div className="about-grid">
            <div className="about-visual reveal">
              <div className="about-img-main">
                <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/f_auto,q_auto/villa_facade_1_dwtqan" alt="Villa Facade" onError={(e) => { (e.currentTarget as unknown as HTMLElement).parentElement!.style.background = "#C4765A"; }} />
              </div>
              <div className="about-img-accent">
                <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_03_ra2fom" alt="Villa Pool & Garden" style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 55%" }} />
              </div>
            </div>
            <div className="about-text">
              <span className="section-label reveal">{t.about_label}</span>
              <h2 className="section-title reveal reveal-delay-1">{t.about_title}</h2>
              <p className="section-text reveal reveal-delay-2">{t.about_text}</p>
              <div className="about-facts reveal reveal-delay-3">
                <div className="fact-card">
                  <span className="fact-num">20</span>
                  <span className="fact-label">{t.fact_villas}</span>
                </div>
                <div className="fact-card">
                  <span className="fact-num">800<small style={{ fontSize: 18 }}>m²</small></span>
                  <span className="fact-label">{t.fact_wellness}</span>
                </div>
                <div className="fact-card">
                  <span className="fact-num">2</span>
                  <span className="fact-label">{t.fact_typologies}</span>
                </div>
                <div className="fact-card">
                  <span className="fact-num">4–5</span>
                  <span className="fact-label">{t.fact_suites}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ DESTINATION — ATLAS + INVESTMENT ═══ */}
      <section className="destination-section" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ position: "relative", minHeight: 520, display: "flex", alignItems: "center" }}>
          <div style={{ position: "absolute", inset: 0, overflow: "hidden" }}>
            <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_04_ohdh9t" alt="Atlas Mountains Marrakech"
              style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 40%" }}
              onError={(e) => { (e.target as HTMLElement).style.display = "none"; }} />
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg,rgba(28,24,18,0.92) 0%,rgba(28,24,18,0.65) 55%,rgba(28,24,18,0.15) 100%)" }} />
          </div>
          <div className="container" style={{ position: "relative", zIndex: 2, paddingTop: 100, paddingBottom: 100 }}>
            <div style={{ maxWidth: 580 }}>
              <span className="section-label reveal" style={{ color: "var(--terracotta)" }}>{t.dest_label}</span>
              <h2 className="section-title reveal reveal-delay-1" style={{ color: "var(--white)" }}>{t.dest_title}</h2>
              <p className="section-text reveal reveal-delay-2" style={{ color: "rgba(255,255,255,0.65)", maxWidth: "100%" }}>{t.dest_text}</p>
            </div>
          </div>
          <div style={{ position: "absolute", bottom: 24, right: 32, zIndex: 2, textAlign: "right" }}>
            <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 13, color: "rgba(255,255,255,0.45)", letterSpacing: 1 }}>{t.atlas_caption}</div>
          </div>
        </div>

        <div style={{ background: "var(--ivory-deep)", padding: "80px 0", borderTop: "1px solid var(--sand)", borderBottom: "1px solid var(--sand)" }}>
          <div className="container">
            <div style={{ textAlign: "center", marginBottom: 56 }}>
              <span className="section-label reveal" style={{ display: "block", textAlign: "center", color: "var(--terracotta)" }}>{t.invest_label}</span>
              <h2 className="section-title reveal reveal-delay-1" style={{ color: "var(--charcoal)", textAlign: "center", maxWidth: 620, margin: "0 auto" }}>{t.invest_title}</h2>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 2 }} className="reveal reveal-delay-2">
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: "36px 28px", textAlign: "center", boxShadow: "0 2px 16px rgba(30,28,24,0.04)" }}>
                <div style={{ fontFamily: "var(--font-serif)", fontSize: 42, fontWeight: 300, color: "var(--terracotta)", lineHeight: 1, marginBottom: 8 }}>{t.inv_stat1_num}</div>
                <div style={{ fontSize: 9, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)", marginBottom: 12 }}>{t.inv_stat1_label}</div>
                <div style={{ fontSize: 12, lineHeight: 1.7, color: "var(--text-light)" }}>{t.inv_stat1_text}</div>
              </div>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: "36px 28px", textAlign: "center", boxShadow: "0 2px 16px rgba(30,28,24,0.04)" }}>
                <div style={{ fontFamily: "var(--font-serif)", fontSize: 42, fontWeight: 300, color: "var(--terracotta)", lineHeight: 1, marginBottom: 8 }}>{t.inv_stat2_num}</div>
                <div style={{ fontSize: 9, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)", marginBottom: 12 }}>{t.inv_stat2_label}</div>
                <div style={{ fontSize: 12, lineHeight: 1.7, color: "var(--text-light)" }}>{t.inv_stat2_text}</div>
              </div>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: "36px 28px", textAlign: "center", boxShadow: "0 2px 16px rgba(30,28,24,0.04)" }}>
                <div style={{ fontFamily: "var(--font-serif)", fontSize: 42, fontWeight: 300, color: "var(--terracotta)", lineHeight: 1, marginBottom: 8 }}>{t.inv_stat3_num}</div>
                <div style={{ fontSize: 9, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)", marginBottom: 12 }}>{t.inv_stat3_label}</div>
                <div style={{ fontSize: 12, lineHeight: 1.7, color: "var(--text-light)" }}>{t.inv_stat3_text}</div>
              </div>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: "36px 28px", textAlign: "center", boxShadow: "0 2px 16px rgba(30,28,24,0.04)" }}>
                <div style={{ fontFamily: "var(--font-serif)", fontSize: 42, fontWeight: 300, color: "var(--terracotta)", lineHeight: 1, marginBottom: 8 }}>{t.inv_stat4_num}</div>
                <div style={{ fontSize: 9, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)", marginBottom: 12 }}>{t.inv_stat4_label}</div>
                <div style={{ fontSize: 12, lineHeight: 1.7, color: "var(--text-light)" }}>{t.inv_stat4_text}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ LOCATION ═══ */}
      <section style={{ background: "var(--cream)", padding: 0 }}>
        <div style={{ position: "relative", height: 520, overflow: "hidden" }}>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d6796.82!2d-8.009578!3d31.541926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMzHCsDMyJzMwLjkiTiA4wrAwMCczNC41Ilc!5e1!3m2!1sen!2sma!4v1700000001"
            width="100%" height="100%"
            style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0, filter: "sepia(10%) contrast(1.05)" }}
            allowFullScreen loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 60, background: "linear-gradient(to bottom,var(--dark),transparent)", pointerEvents: "none", zIndex: 1 }} />
          <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", zIndex: 2, pointerEvents: "none" }}>
            <div style={{ background: "var(--terracotta)", color: "var(--white)", padding: "10px 20px", fontFamily: "var(--font-serif)", fontSize: 15, whiteSpace: "nowrap", boxShadow: "0 8px 32px rgba(196,118,90,0.5)", textAlign: "center" }}>
              <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "rgba(255,255,255,0.7)", marginBottom: 3 }}>{t.map_label}</div>
              Zaytoun Marrakech
            </div>
            <div style={{ width: 2, height: 20, background: "var(--terracotta)", margin: "0 auto", boxShadow: "0 4px 8px rgba(196,118,90,0.4)" }} />
          </div>
          <a href="https://maps.app.goo.gl/9A2nFLYgWW464MUz7" target="_blank" rel="noopener"
            style={{ position: "absolute", top: 20, right: 20, zIndex: 2, background: "rgba(28,24,18,0.88)", backdropFilter: "blur(10px)", color: "var(--gold-light)", fontFamily: "var(--font-sans)", fontSize: 9, letterSpacing: 2, textTransform: "uppercase", padding: "10px 16px", textDecoration: "none", border: "1px solid rgba(184,150,62,0.3)", transition: "all 0.3s", display: "flex", alignItems: "center", gap: 6 }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--gold)"; e.currentTarget.style.color = "var(--gold)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(184,150,62,0.3)"; e.currentTarget.style.color = "var(--gold-light)"; }}
          >
            {t.map_open}
          </a>
        </div>

        <div className="container" style={{ paddingTop: 0, paddingBottom: 80 }}>
          <div style={{ background: "var(--white)", marginTop: 0, padding: 0 }}>
            <div style={{ background: "var(--charcoal)", padding: "32px 48px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 20 }}>
              <div>
                <span style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", display: "block", marginBottom: 6 }}>{t.loc_label}</span>
                <span style={{ fontFamily: "var(--font-serif)", fontSize: 22, color: "var(--white)" }}>Route de Tahannouat, Marrakech</span>
              </div>
              <div style={{ display: "flex", gap: 32 }}>
                <div style={{ textAlign: "center" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 28, fontWeight: 300, color: "var(--gold-light)", display: "block", lineHeight: 1 }}>5&apos;</span>
                  <span style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "rgba(255,255,255,0.35)" }}>{t.dist_golf}</span>
                </div>
                <div style={{ textAlign: "center" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 28, fontWeight: 300, color: "var(--gold-light)", display: "block", lineHeight: 1 }}>20&apos;</span>
                  <span style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "rgba(255,255,255,0.35)" }}>{t.dist_hivernage}</span>
                </div>
                <div style={{ textAlign: "center" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 28, fontWeight: 300, color: "var(--gold-light)", display: "block", lineHeight: 1 }}>20&apos;</span>
                  <span style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "rgba(255,255,255,0.35)" }}>{t.dist_airport}</span>
                </div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 0, borderTop: "none" }}>
              <div style={{ padding: "40px 36px", borderRight: "1px solid var(--sand)", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 24, right: 24, fontSize: 32, opacity: 0.08 }}>⛳</div>
                <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 12 }}>{t.loc_golf_label}</div>
                <h3 style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--dark)", marginBottom: 14, fontWeight: 400 }}>{t.loc_golf_title}</h3>
                <p style={{ fontSize: 13, lineHeight: 1.8, color: "var(--text-light)" }}>{t.loc_golf_text}</p>
                <div style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--sand)" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Amelkis Golf Club</strong> — 5 min</span>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Noria Golf Club</strong> — 5 min</span>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Argan Golf Resort</strong> — 7 min</span>
                  </div>
                </div>
              </div>
              <div style={{ padding: "40px 36px", borderRight: "1px solid var(--sand)", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 24, right: 24, fontSize: 32, opacity: 0.08 }}>🌆</div>
                <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 12 }}>{t.loc_hiv_label}</div>
                <h3 style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--dark)", marginBottom: 14, fontWeight: 400 }}>{t.loc_hiv_title}</h3>
                <p style={{ fontSize: 13, lineHeight: 1.8, color: "var(--text-light)" }}>{t.loc_hiv_text}</p>
                <div style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--sand)" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Hivernage</strong> — 20 min</span>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Jamaa el-Fna</strong> — 20 min</span>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Gueliz (City Centre)</strong> — 18 min</span>
                  </div>
                </div>
              </div>
              <div style={{ padding: "40px 36px", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 24, right: 24, fontSize: 32, opacity: 0.08 }}>✈</div>
                <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 12 }}>{t.loc_air_label}</div>
                <h3 style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--dark)", marginBottom: 14, fontWeight: 400 }}>{t.loc_air_title}</h3>
                <p style={{ fontSize: 13, lineHeight: 1.8, color: "var(--text-light)" }}>{t.loc_air_text}</p>
                <div style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--sand)" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Paris CDG</strong> — 3h30 direct</span>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>London LHR</strong> — 3h45 direct</span>
                    <span style={{ fontSize: 12, color: "var(--text-light)" }}>⬦ <strong style={{ color: "var(--dark)" }}>Dubai DXB</strong> — 6h direct</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ WELLNESS ═══ */}
      <section style={{ background: "var(--dark)", position: "relative", overflow: "hidden", minHeight: 700, display: "flex", alignItems: "flex-end" }}>
        <div style={{ position: "absolute", inset: 0 }}>
          <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_05_bawka8" alt="Wellness Center Zaytoun"
            style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 30%" }} />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(105deg,rgba(28,24,18,0.92) 0%,rgba(28,24,18,0.72) 40%,rgba(28,24,18,0.10) 100%)" }} />
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 80, background: "linear-gradient(to top,var(--dark),transparent)", pointerEvents: "none" }} />
        </div>
        <div className="container" style={{ position: "relative", zIndex: 2, paddingTop: 120, paddingBottom: 80, width: "100%" }}>
          <span className="section-label reveal" style={{ color: "var(--terracotta)" }}>{t.well_label}</span>
          <h2 className="section-title reveal reveal-delay-1" style={{ color: "var(--white)", maxWidth: 560 }}>{t.well_title}</h2>
          <p className="section-text reveal reveal-delay-2" style={{ color: "rgba(255,255,255,0.6)", maxWidth: 480, marginBottom: 56 }}>{t.well_text}</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,220px))", gap: 2 }} className="reveal reveal-delay-3">
            <div style={{ background: "rgba(20,16,10,0.6)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)", padding: "28px 22px" }}>
              <div style={{ fontSize: 20, color: "var(--gold-light)", marginBottom: 14 }}>◈</div>
              <div style={{ fontFamily: "var(--font-serif)", fontSize: 17, color: "var(--white)", marginBottom: 8 }}>{t.wf1_title}</div>
              <div style={{ fontSize: 12, lineHeight: 1.75, color: "rgba(255,255,255,0.5)" }}>{t.wf1_text}</div>
            </div>
            <div style={{ background: "rgba(20,16,10,0.6)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)", padding: "28px 22px" }}>
              <div style={{ fontSize: 20, color: "var(--gold-light)", marginBottom: 14 }}>◯</div>
              <div style={{ fontFamily: "var(--font-serif)", fontSize: 17, color: "var(--white)", marginBottom: 8 }}>{t.wf2_title}</div>
              <div style={{ fontSize: 12, lineHeight: 1.75, color: "rgba(255,255,255,0.5)" }}>{t.wf2_text}</div>
            </div>
            <div style={{ background: "rgba(20,16,10,0.6)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)", padding: "28px 22px" }}>
              <div style={{ fontSize: 20, color: "var(--gold-light)", marginBottom: 14 }}>❧</div>
              <div style={{ fontFamily: "var(--font-serif)", fontSize: 17, color: "var(--white)", marginBottom: 8 }}>{t.wf3_title}</div>
              <div style={{ fontSize: 12, lineHeight: 1.75, color: "rgba(255,255,255,0.5)" }}>{t.wf3_text}</div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ GATE SECTION ═══ */}
      <section className="gate-section" id="gate">
        <div className="container-narrow">
          <div className="gate-inner">
            <div className="gate-icon">
              <div className="gate-icon-inner">
                <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
              </div>
            </div>
            <p className="gate-label">{t.gate_label}</p>
            <h2 className="gate-title">{t.gate_title}</h2>
            <p className="gate-subtitle">{t.gate_subtitle}</p>

            <div className="locked-items">
              <div className="locked-item">
                <svg className="lock-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <span>{t.lock1}</span>
              </div>
              <div className="locked-item">
                <svg className="lock-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <span>{t.lock2}</span>
              </div>
              <div className="locked-item">
                <svg className="lock-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <span>{t.lock3}</span>
              </div>
              <div className="locked-item">
                <svg className="lock-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <span>{t.lock4}</span>
              </div>
              <div className="locked-item">
                <svg className="lock-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <span>{t.lock5}</span>
              </div>
            </div>

            <div className={`gate-form-wrap ${!showForm ? "hide" : ""}`}>
              {showForm && (
                <form className="gate-form" onSubmit={handleGateSubmit}>
                  <div className="gate-form-inner">
                    <div className="form-field">
                      <label className="form-label">{t.form_firstname}</label>
                      <input className="form-input" type="text" name="fname" required autoComplete="given-name" placeholder={t.form_firstname_ph} />
                    </div>
                    <div className="form-field">
                      <label className="form-label">{t.form_lastname}</label>
                      <input className="form-input" type="text" name="lname" required autoComplete="family-name" placeholder={t.form_lastname_ph} />
                    </div>
                    <div className="form-field">
                      <label className="form-label">{t.form_email}</label>
                      <input className="form-input" type="email" name="email" required autoComplete="email" placeholder={t.form_email_ph} />
                    </div>
                    <div className="form-field">
                      <label className="form-label">{t.form_phone}</label>
                      <input className="form-input" type="tel" name="phone" required autoComplete="tel" placeholder={t.form_phone_ph} />
                    </div>
                    <div className="form-field">
                      <label className="form-label">{t.form_country}</label>
                      <select className="form-input form-select" name="country" required defaultValue="">
                        <option value="" disabled>{t.form_country_ph}</option>
                        <option value="MA">Morocco</option>
                        <option value="FR">France</option>
                        <option value="BE">Belgium</option>
                        <option value="CH">Switzerland</option>
                        <option value="AE">UAE</option>
                        <option value="SA">Saudi Arabia</option>
                        <option value="QA">Qatar</option>
                        <option value="GB">United Kingdom</option>
                        <option value="US">United States</option>
                        <option value="CA">Canada</option>
                        <option value="OTHER">Other</option>
                      </select>
                    </div>
                    <div className="form-field">
                      <label className="form-label">{t.form_intent}</label>
                      <select className="form-input form-select" name="intent" required defaultValue="">
                        <option value="" disabled>{t.form_intent_ph}</option>
                        <option value="primary">{t.intent1}</option>
                        <option value="investment">{t.intent2}</option>
                        <option value="secondary">{t.intent3}</option>
                        <option value="exploring">{t.intent4}</option>
                      </select>
                    </div>
                  </div>
                  <button type="submit" className="gate-submit" disabled={createLead.isPending}>
                    {createLead.isPending ? (lang === "ar" ? "جارٍ الفتح…" : "Unlocking…") : t.gate_submit}
                  </button>
                  <p className="gate-privacy">{t.gate_privacy}</p>
                </form>
              )}
              <div className={`gate-success ${!showForm ? "show" : ""}`}>
                <div className="success-icon">
                  <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div className="success-title">{t.success_title}</div>
                <div className="success-text">{t.success_text}</div>
                <div className="success-scroll-hint">{t.success_scroll}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ DOSSIER (LOCKED) ═══ */}
      <div className={`dossier-section ${dossierUnlocked ? "visible" : ""}`} id="dossier">
        <div className="dossier-header">
          <div className="unlock-animation">
            <div className="unlock-icon">
              <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>
            </div>
            <div className="unlock-line">{t.dossier_unlocked}</div>
          </div>
          <span className="section-label">{t.dossier_label}</span>
          <h2 className="section-title">{t.dossier_title}</h2>
          <p className="section-text">{t.dossier_text}</p>
        </div>

        <div className="container">
          <div className="dossier-tabs">
            <button className={`tab-btn ${activeTab === "villas" ? "active" : ""}`} onClick={() => handleTabChange("villas")}>{t.tab_villas}</button>
            <button className={`tab-btn ${activeTab === "interiors" ? "active" : ""}`} onClick={() => handleTabChange("interiors")}>{t.tab_interiors}</button>
            <button className={`tab-btn ${activeTab === "floorplans" ? "active" : ""}`} onClick={() => handleTabChange("floorplans")}>{t.tab_plans}</button>
            <button className={`tab-btn ${activeTab === "pricing" ? "active" : ""}`} onClick={() => handleTabChange("pricing")}>{t.tab_pricing}</button>
            <button className={`tab-btn ${activeTab === "finishes" ? "active" : ""}`} onClick={() => handleTabChange("finishes")}>{t.tab_finishes}</button>
            <button className={`tab-btn ${activeTab === "services" ? "active" : ""}`} onClick={() => handleTabChange("services")}>{t.tab_services}</button>
          </div>

          {/* VILLAS TAB */}
          <div className={`tab-content ${activeTab === "villas" ? "active" : ""}`}>
            <div className="villa-grid">
              <div className="villa-card">
                <div className="villa-img">
                  <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/f_auto,q_auto/villa_facade_1_dwtqan" alt="Villa Arbea — Facade" onError={(e) => { (e.currentTarget as unknown as HTMLElement).parentElement!.style.background = "#C4765A"; }} />
                </div>
                <div className="villa-info">
                  <div className="villa-name">{t.villa_arbea}</div>
                  <div className="villa-specs">
                    <div className="spec-item">
                      <span className="spec-val">5</span>
                      <span className="spec-key">{t.spec_suites}</span>
                    </div>
                    <div className="spec-item">
                      <span className="spec-val">R+1</span>
                      <span className="spec-key">{t.spec_levels}</span>
                    </div>
                    <div className="spec-item">
                      <span className="spec-val">∞</span>
                      <span className="spec-key">{t.spec_pool}</span>
                    </div>
                    <div className="spec-item">
                      <span className="spec-val">2+2</span>
                      <span className="spec-key">{t.spec_parking}</span>
                    </div>
                  </div>
                  <p className="section-text" style={{ fontSize: 13 }}>{t.arbea_desc}</p>
                </div>
              </div>
              <div className="villa-card">
                <div className="villa-img">
                  <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_03_ra2fom" alt="Villa Ziria — Garden & Pool View" onError={(e) => { (e.currentTarget as unknown as HTMLElement).parentElement!.style.background = "#3D5A2B"; }} />
                </div>
                <div className="villa-info">
                  <div className="villa-name">{t.villa_ziria}</div>
                  <div className="villa-specs">
                    <div className="spec-item">
                      <span className="spec-val">4</span>
                      <span className="spec-key">{t.spec_suites}</span>
                    </div>
                    <div className="spec-item">
                      <span className="spec-val">R+1</span>
                      <span className="spec-key">{t.spec_levels}</span>
                    </div>
                    <div className="spec-item">
                      <span className="spec-val">∞</span>
                      <span className="spec-key">{t.spec_pool}</span>
                    </div>
                    <div className="spec-item">
                      <span className="spec-val">2+2</span>
                      <span className="spec-key">{t.spec_parking}</span>
                    </div>
                  </div>
                  <p className="section-text" style={{ fontSize: 13 }}>{t.ziria_desc}</p>
                </div>
              </div>
            </div>
          </div>

          {/* INTERIORS TAB */}
          <div className={`tab-content ${activeTab === "interiors" ? "active" : ""}`}>
            <div style={{ marginBottom: 40, paddingBottom: 32, borderBottom: "1px solid var(--sand)" }}>
              <span style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", display: "block", marginBottom: 8 }}>{t.int_label}</span>
              <h3 style={{ fontFamily: "var(--font-serif)", fontSize: 26, fontWeight: 300, color: "var(--charcoal)" }}>{t.int_title}</h3>
              <p style={{ fontSize: 13, color: "var(--text-light)", marginTop: 8, maxWidth: 560, lineHeight: 1.8 }}>{t.int_subtitle}</p>
            </div>
            <div className="interiors-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
              <div className="interior-card" style={{ gridColumn: "span 2" }}>
                <div style={{ overflow: "hidden", background: "var(--cream)" }}>
                  <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/v1776250352/Capture_d_e%CC%81cran_2026-04-15_a%CC%80_11.45.28_bmk6ig"
                    alt="Salon" style={{ width: "100%", height: 460, objectFit: "cover", objectPosition: "center", display: "block" }} />
                </div>
                <div style={{ padding: "16px 0 8px", display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 18, color: "var(--charcoal)" }}>{t.int_salon}</span>
                  <span style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "var(--text-light)" }}>{t.int_villa_a}</span>
                </div>
                <p style={{ fontSize: 12, color: "var(--text-light)", lineHeight: 1.7 }}>{t.int_salon_desc}</p>
              </div>
              <div className="interior-card">
                <div style={{ overflow: "hidden", background: "var(--cream)" }}>
                  <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/v1776250367/Capture_d_e%CC%81cran_2026-04-15_a%CC%80_11.47.01_bkbqoz"
                    alt="Shower" style={{ width: "100%", height: 320, objectFit: "cover", objectPosition: "center", display: "block" }} />
                </div>
                <div style={{ padding: "16px 0 8px", display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 18, color: "var(--charcoal)" }}>{t.int_shower}</span>
                  <span style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "var(--text-light)" }}>{t.int_villa_ab}</span>
                </div>
                <p style={{ fontSize: 12, color: "var(--text-light)", lineHeight: 1.7 }}>{t.int_shower_desc}</p>
              </div>
              <div className="interior-card">
                <div style={{ overflow: "hidden", background: "var(--cream)" }}>
                  <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/v1776250360/Capture_d_e%CC%81cran_2026-04-15_a%CC%80_11.47.27_gl5qm3"
                    alt="Vanity" style={{ width: "100%", height: 320, objectFit: "cover", objectPosition: "center", display: "block" }} />
                </div>
                <div style={{ padding: "16px 0 8px", display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 18, color: "var(--charcoal)" }}>{t.int_vanity}</span>
                  <span style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "var(--text-light)" }}>{t.int_villa_ab}</span>
                </div>
                <p style={{ fontSize: 12, color: "var(--text-light)", lineHeight: 1.7 }}>{t.int_vanity_desc}</p>
              </div>
              <div className="interior-card" style={{ gridColumn: "span 2" }}>
                <div style={{ overflow: "hidden", background: "var(--cream)" }}>
                  <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/v1776250757/Capture_d_e%CC%81cran_2026-04-15_a%CC%80_11.58.02_xdy6iv"
                    alt="Bedroom" style={{ width: "100%", height: 460, objectFit: "cover", objectPosition: "center", display: "block" }} />
                </div>
                <div style={{ padding: "16px 0 8px", display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <span style={{ fontFamily: "var(--font-serif)", fontSize: 18, color: "var(--charcoal)" }}>{t.int_bedroom}</span>
                  <span style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "var(--text-light)" }}>{t.int_villa_ab}</span>
                </div>
                <p style={{ fontSize: 12, color: "var(--text-light)", lineHeight: 1.7 }}>{t.int_bedroom_desc}</p>
              </div>
            </div>
            <div style={{ marginTop: 40, padding: "28px 32px", background: "var(--ivory-deep)", border: "1px solid var(--sand)", display: "flex", alignItems: "center", gap: 20 }}>
              <div style={{ fontSize: 24, color: "var(--gold)" }}>◈</div>
              <div>
                <div style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 4 }}>{t.int_note_label}</div>
                <p style={{ fontSize: 13, color: "var(--text-mid)", lineHeight: 1.7 }}>{t.int_note_text}</p>
              </div>
            </div>
          </div>

          {/* FLOOR PLANS TAB */}
          <div className={`tab-content ${activeTab === "floorplans" ? "active" : ""}`}>
            <div style={{ marginBottom: 56 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20, paddingBottom: 16, borderBottom: "1px solid var(--sand)" }}>
                <div>
                  <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 6 }}>{t.plan_mp_label}</div>
                  <div style={{ fontFamily: "var(--font-serif)", fontSize: 24, color: "var(--dark)" }}>{t.plan_mp_title}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontFamily: "var(--font-serif)", fontSize: 22, color: "var(--terracotta)" }}>20 <span style={{ fontSize: 14 }}>villas · 4.4 Ha</span></div>
                </div>
              </div>
              <div style={{ background: "var(--cream)", padding: 16, border: "1px solid var(--sand)", overflow: "hidden" }}>
                <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/f_auto,q_auto/plan_masse_e65fhr" alt="Zaytoun Marrakech — Plan de Masse 1:1000"
                  style={{ width: "100%", height: "auto", display: "block" }} />
              </div>
              <p style={{ fontSize: 11, color: "var(--text-light)", marginTop: 8, fontStyle: "italic", textAlign: "center" }}>{t.plan_zoom_hint}</p>
            </div>
            <div style={{ marginBottom: 56 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20, paddingBottom: 16, borderBottom: "1px solid var(--sand)" }}>
                <div>
                  <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 6 }}>{t.plan_arbea_label}</div>
                  <div style={{ fontFamily: "var(--font-serif)", fontSize: 24, color: "var(--dark)" }}>{t.plan_arbea_title}</div>
                </div>
                <div style={{ display: "flex", gap: 28, textAlign: "center" }}>
                  <div><div style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--terracotta)" }}>5</div><div style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--text-light)" }}>{t.spec_suites}</div></div>
                  <div><div style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--terracotta)" }}>R+1</div><div style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--text-light)" }}>{t.spec_levels}</div></div>
                  <div><div style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--terracotta)" }}>∞</div><div style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--text-light)" }}>{t.spec_pool}</div></div>
                </div>
              </div>
              <div style={{ background: "var(--cream)", padding: 16, border: "1px solid var(--sand)", overflow: "hidden" }}>
                <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/f_auto,q_auto/villa_a_gfkdew" alt="Villa Arbea Type A"
                  style={{ width: "100%", height: "auto", display: "block" }} />
              </div>
              <p style={{ fontSize: 11, color: "var(--text-light)", marginTop: 8, fontStyle: "italic", textAlign: "center" }}>{t.plan_zoom_hint}</p>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20, paddingBottom: 16, borderBottom: "1px solid var(--sand)" }}>
                <div>
                  <div style={{ fontSize: 9, letterSpacing: 3, textTransform: "uppercase", color: "var(--terracotta)", marginBottom: 6 }}>{t.plan_ziria_label}</div>
                  <div style={{ fontFamily: "var(--font-serif)", fontSize: 24, color: "var(--dark)" }}>{t.plan_ziria_title}</div>
                </div>
                <div style={{ display: "flex", gap: 28, textAlign: "center" }}>
                  <div><div style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--terracotta)" }}>4</div><div style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--text-light)" }}>{t.spec_suites}</div></div>
                  <div><div style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--terracotta)" }}>R+1</div><div style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--text-light)" }}>{t.spec_levels}</div></div>
                  <div><div style={{ fontFamily: "var(--font-serif)", fontSize: 20, color: "var(--terracotta)" }}>∞</div><div style={{ fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--text-light)" }}>{t.spec_pool}</div></div>
                </div>
              </div>
              <div style={{ background: "var(--cream)", padding: 16, border: "1px solid var(--sand)", overflow: "hidden" }}>
                <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/f_auto,q_auto/villa_b_hvgvxx" alt="Villa Ziria Type B"
                  style={{ width: "100%", height: "auto", display: "block" }} />
              </div>
              <p style={{ fontSize: 11, color: "var(--text-light)", marginTop: 8, fontStyle: "italic", textAlign: "center" }}>{t.plan_zoom_hint}</p>
            </div>
          </div>

          {/* PRICING TAB */}
          <div className={`tab-content ${activeTab === "pricing" ? "active" : ""}`}>
            <div className="pricing-block">
              <p className="price-from">{t.price_from}</p>
              <div className="price-amount">
                <span className="price-currency">MAD </span>9,700,000
              </div>
              <p className="price-note">{t.price_note}</p>
            </div>
            <h3 style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 24, fontWeight: 300, color: "#1C1812", marginBottom: 32, textAlign: "center" }}>{t.payment_title}</h3>
            <div className="payment-plan">
              <div className="payment-step" style={{ gridColumn: "span 2" }}>
                <span className="payment-pct" style={{ fontSize: 52 }}>30%</span>
                <span className="payment-when">{t.pay1}</span>
              </div>
              <div className="payment-step" style={{ gridColumn: "span 2", background: "var(--ivory-deep)" }}>
                <span className="payment-pct" style={{ fontSize: 52 }}>70%</span>
                <span className="payment-when">{t.pay4}</span>
              </div>
            </div>
            <div className="handover-block">
              <div className="handover-text">
                <h3 className="section-title">{t.handover_title}</h3>
                <p className="section-text">{t.handover_text}</p>
              </div>
              <div className="handover-date" style={{ display: "flex", gap: 32, alignItems: "flex-start" }}>
                <div style={{ textAlign: "center" }}>
                  <span className="handover-date-num" style={{ fontSize: 36 }}>Q3</span>
                  <span className="handover-date-year" style={{ fontSize: 22 }}>2027</span>
                  <span className="handover-date-label" style={{ fontSize: 9, letterSpacing: 1.5, display: "block", marginTop: 4 }}>Phase 1</span>
                </div>
                <div style={{ color: "var(--sand)", fontFamily: "var(--font-serif)", fontSize: 32, lineHeight: 1.8 }}>·</div>
                <div style={{ textAlign: "center" }}>
                  <span className="handover-date-num" style={{ fontSize: 36 }}>Q2</span>
                  <span className="handover-date-year" style={{ fontSize: 22 }}>2028</span>
                  <span className="handover-date-label" style={{ fontSize: 9, letterSpacing: 1.5, display: "block", marginTop: 4 }}>Phases 2 &amp; 3</span>
                </div>
              </div>
            </div>
          </div>

          {/* FINISHES TAB */}
          <div className={`tab-content ${activeTab === "finishes" ? "active" : ""}`}>
            <div className="finishes-list">
              <div className="finish-category">
                <div className="finish-cat-title">{t.fin_floor}</div>
                <ul className="finish-items">
                  <li>{t.fin_f1}</li>
                  <li>{t.fin_f2}</li>
                  <li>{t.fin_f3}</li>
                  <li>{t.fin_f4}</li>
                  <li>{t.fin_f5}</li>
                </ul>
              </div>
              <div className="finish-category">
                <div className="finish-cat-title">{t.fin_carp}</div>
                <ul className="finish-items">
                  <li>{t.fin_c1}</li>
                  <li>{t.fin_c2}</li>
                  <li>{t.fin_c3}</li>
                  <li>{t.fin_c4}</li>
                  <li>{t.fin_c5}</li>
                  <li>{t.fin_c6}</li>
                </ul>
              </div>
              <div className="finish-category">
                <div className="finish-cat-title">{t.fin_struct}</div>
                <ul className="finish-items">
                  <li>{t.fin_s1}</li>
                  <li>{t.fin_s2}</li>
                  <li>{t.fin_s3}</li>
                  <li>{t.fin_s4}</li>
                  <li>{t.fin_s5}</li>
                  <li>{t.fin_s6}</li>
                </ul>
              </div>
              <div className="finish-category">
                <div className="finish-cat-title">{t.fin_tech}</div>
                <ul className="finish-items">
                  <li>{t.fin_t1}</li>
                  <li>{t.fin_t2}</li>
                  <li>{t.fin_t3}</li>
                  <li>{t.fin_t4}</li>
                  <li>{t.fin_t5}</li>
                </ul>
              </div>
              <div className="finish-category">
                <div className="finish-cat-title">{t.fin_out}</div>
                <ul className="finish-items">
                  <li>{t.fin_o1}</li>
                  <li>{t.fin_o2}</li>
                  <li>{t.fin_o3}</li>
                  <li>{t.fin_o4}</li>
                </ul>
              </div>
            </div>
          </div>

          {/* SERVICES TAB */}
          <div className={`tab-content ${activeTab === "services" ? "active" : ""}`}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: 40 }}>
                <div className="wf-icon" style={{ margin: "0 0 24px" }}>◈</div>
                <div className="wf-title">{t.svc1_title}</div>
                <p className="wf-text">{t.svc1_text}</p>
              </div>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: 40 }}>
                <div className="wf-icon" style={{ margin: "0 0 24px" }}>◯</div>
                <div className="wf-title">{t.svc2_title}</div>
                <p className="wf-text">{t.svc2_text}</p>
              </div>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: 40 }}>
                <div className="wf-icon" style={{ margin: "0 0 24px" }}>❧</div>
                <div className="wf-title">{t.svc3_title}</div>
                <p className="wf-text">{t.svc3_text}</p>
              </div>
              <div style={{ background: "var(--white)", border: "1px solid var(--sand)", padding: 40 }}>
                <div className="wf-icon" style={{ margin: "0 0 24px" }}>⬡</div>
                <div className="wf-title">{t.svc4_title}</div>
                <p className="wf-text">{t.svc4_text}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ═══ CTA ═══ */}
      <section className="cta-section" id="cta">
        <div className="container">
          <h2 className="section-title">{t.cta_title}</h2>
          <p className="section-text">{t.cta_text}</p>
          <div className="cta-btns">
            <a href="tel:+212777474747" className="btn-white">{t.cta_call}</a>
            <a href="mailto:sales@arabesque.life" className="btn-ghost-white">{t.cta_email}</a>
          </div>
        </div>
      </section>

      {/* ═══ FOOTER ═══ */}
      <footer>
        <div className="container">
          <div className="footer-grid">
            <div className="footer-brand">
              <img src="https://res.cloudinary.com/dlidh4fdt/image/upload/img_11_ep2mob" alt="Arabesque" onError={(e) => { (e.target as HTMLElement).style.display = "none"; }} />
              <p className="footer-tagline">{t.footer_tagline}</p>
            </div>
            <div>
              <div className="footer-col-title">{t.footer_nav}</div>
              <ul className="footer-links">
                <li><a href="#" onClick={(e) => { e.preventDefault(); document.querySelector(".hero")?.scrollIntoView({ behavior: "smooth" }); }}>{t.nav_home}</a></li>
                <li><a href="#" onClick={(e) => { e.preventDefault(); document.querySelector(".about-section")?.scrollIntoView({ behavior: "smooth" }); }}>{t.nav_project}</a></li>
                <li><a href="#" onClick={(e) => { e.preventDefault(); document.querySelector(".destination-section")?.scrollIntoView({ behavior: "smooth" }); }}>{t.nav_dest}</a></li>
                <li><a href="#" onClick={(e) => { e.preventDefault(); document.getElementById("gate")?.scrollIntoView({ behavior: "smooth" }); }}>{t.nav_dossier}</a></li>
              </ul>
            </div>
            <div>
              <div className="footer-col-title">{t.footer_contact}</div>
              <span className="footer-contact-item"><a href="tel:+212777474747">+212 777 47 47 47</a></span>
              <span className="footer-contact-item"><a href="mailto:sales@arabesque.life">sales@arabesque.life</a></span>
              <span className="footer-contact-item" style={{ marginTop: 8 }}>Route de Tahannouat<br />Marrakech, Maroc</span>
            </div>
          </div>
          <div className="footer-bottom">
            <div className="footer-copy">© 2026 Zaytoun Marrakech — Arabesque Residences / M Properties Dev</div>
          </div>
          <p className="footer-disclaimer">{t.disclaimer}</p>
        </div>
      </footer>

      {/* WhatsApp floating button */}
      <a href="https://wa.me/212777474747" target="_blank" rel="noopener" aria-label="WhatsApp"
        style={{ position: "fixed", bottom: 28, right: 28, zIndex: 9999, width: 56, height: 56, background: "#25D366", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 20px rgba(37,211,102,0.45)", transition: "transform 0.3s,box-shadow 0.3s", textDecoration: "none" }}
        onMouseEnter={(e) => { e.currentTarget.style.transform = "scale(1.1)"; e.currentTarget.style.boxShadow = "0 6px 28px rgba(37,211,102,0.6)"; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "0 4px 20px rgba(37,211,102,0.45)"; }}
      >
        <svg width="26" height="26" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>
      </a>
    </div>
  );
}
