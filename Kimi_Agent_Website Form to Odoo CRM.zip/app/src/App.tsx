import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Login from "./pages/Login"
import AdminLeads from "./pages/AdminLeads"
import NotFound from "./pages/NotFound"

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/admin/leads" element={<AdminLeads />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
