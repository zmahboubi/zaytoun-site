import { env } from "./env";

export interface OdooConfig {
  url: string;
  db: string;
  username: string;
  password: string;
}

export interface LeadPayload {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  country: string;
  intent: string;
  lang: string;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  referrer?: string;
}

function getOdooConfig(): OdooConfig | null {
  const { odooUrl: url, odooDb: db, odooUser: username, odooPassword: password } = env;

  if (!url || !db || !username || !password) {
    return null;
  }

  return { url, db, username, password };
}

async function jsonRpc(
  url: string,
  service: string,
  method: string,
  args: unknown[] = [],
): Promise<unknown> {
  const body = {
    jsonrpc: "2.0",
    method: "call",
    params: { service, method, args },
    id: Math.floor(Math.random() * 100000),
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    throw new Error(`Odoo JSON-RPC HTTP ${res.status}`);
  }

  const data = (await res.json()) as {
    result?: unknown;
    error?: { message?: string; data?: { message?: string } };
  };

  if (data.error) {
    const msg =
      data.error.data?.message || data.error.message || "Odoo JSON-RPC error";
    throw new Error(msg);
  }

  return data.result;
}

export async function createOdooLead(
  payload: LeadPayload,
): Promise<{ leadId: number; syncedAt: Date }> {
  const config = getOdooConfig();
  if (!config) {
    throw new Error("Odoo not configured");
  }

  const { url, db, username, password } = config;

  // 1. Authenticate
  const uid = (await jsonRpc(`${url}/jsonrpc/2/common`, "common", "authenticate", [
    db,
    username,
    password,
    {},
  ])) as number;

  if (!uid || typeof uid !== "number") {
    throw new Error("Odoo authentication failed");
  }

  // 2. Map intent to French labels for Odoo
  const intentMap: Record<string, string> = {
    primary: "Résidence Principale",
    investment: "Investissement / Locatif",
    secondary: "Résidence Secondaire",
    exploring: "En cours de réflexion",
  };

  const description = [
    `Pays de résidence : ${payload.country}`,
    `Intention d'achat : ${intentMap[payload.intent] || payload.intent}`,
    `Langue : ${payload.lang.toUpperCase()}`,
    `Source : Formulaire teaser Zaytoun (site pré-lancement)`,
    payload.utmSource ? `UTM Source : ${payload.utmSource}` : null,
    payload.utmMedium ? `UTM Medium : ${payload.utmMedium}` : null,
    payload.utmCampaign ? `UTM Campaign : ${payload.utmCampaign}` : null,
    payload.referrer ? `Referrer : ${payload.referrer}` : null,
  ]
    .filter(Boolean)
    .join("\n");

  // 3. Create crm.lead
  const leadValues = {
    name: `[Zaytoun] ${payload.firstName} ${payload.lastName}`,
    contact_name: `${payload.firstName} ${payload.lastName}`,
    email_from: payload.email,
    phone: payload.phone,
    description,
    type: "lead",
  };

  const leadId = (await jsonRpc(
    `${url}/jsonrpc/2/object`,
    "object",
    "execute_kw",
    [db, uid, password, "crm.lead", "create", [leadValues]],
  )) as number;

  if (!leadId || typeof leadId !== "number") {
    throw new Error("Odoo lead creation returned invalid ID");
  }

  return { leadId, syncedAt: new Date() };
}
