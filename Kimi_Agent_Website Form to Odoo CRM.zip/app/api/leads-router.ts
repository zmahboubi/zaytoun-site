import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { leads } from "@db/schema";
import { createOdooLead, type LeadPayload } from "./lib/odoo";
import { eq, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

const createLeadInput = z.object({
  firstName: z.string().min(1).max(255),
  lastName: z.string().min(1).max(255),
  email: z.string().email(),
  phone: z.string().min(1).max(255),
  country: z.string().min(1).max(255),
  intent: z.string().min(1).max(255),
  lang: z.string().min(1).max(10).default("en"),
  utmSource: z.string().optional(),
  utmMedium: z.string().optional(),
  utmCampaign: z.string().optional(),
  referrer: z.string().optional(),
});

export const leadsRouter = createRouter({
  create: publicQuery
    .input(createLeadInput)
    .mutation(async ({ input }) => {
      const db = getDb();

      // Insert lead into database
      const [lead] = await db.insert(leads).values({
        firstName: input.firstName,
        lastName: input.lastName,
        email: input.email,
        phone: input.phone,
        country: input.country,
        intent: input.intent,
        lang: input.lang,
        utmSource: input.utmSource,
        utmMedium: input.utmMedium,
        utmCampaign: input.utmCampaign,
        referrer: input.referrer,
      });

      if (!lead) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create lead",
        });
      }

      // Attempt to sync with Odoo CRM (best-effort)
      let odooLeadId: string | null = null;
      let odooSyncedAt: Date | null = null;
      let odooSyncError: string | null = null;

      try {
        const odooPayload: LeadPayload = {
          firstName: input.firstName,
          lastName: input.lastName,
          email: input.email,
          phone: input.phone,
          country: input.country,
          intent: input.intent,
          lang: input.lang,
          utmSource: input.utmSource,
          utmMedium: input.utmMedium,
          utmCampaign: input.utmCampaign,
          referrer: input.referrer,
        };

        const result = await createOdooLead(odooPayload);
        odooLeadId = String(result.leadId);
        odooSyncedAt = result.syncedAt;
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        odooSyncError = message;
        console.warn("[Leads] Odoo sync failed:", message);
      }

      // Update lead with Odoo sync status
      const insertedId = Number(lead.insertId);
      if (insertedId) {
        await db
          .update(leads)
          .set({
            odooLeadId: odooLeadId ?? undefined,
            odooSyncedAt: odooSyncedAt ?? undefined,
            odooSyncError: odooSyncError ?? undefined,
          })
          .where(eq(leads.id, insertedId));
      }

      return {
        success: true,
        leadId: insertedId,
        odooSynced: !!odooLeadId,
        odooLeadId,
        odooSyncError,
      };
    }),

  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(leads).orderBy(desc(leads.createdAt));
  }),

  retryOdooSync: adminQuery
    .input(z.object({ leadId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [lead] = await db
        .select()
        .from(leads)
        .where(eq(leads.id, input.leadId))
        .limit(1);

      if (!lead) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Lead not found",
        });
      }

      try {
        const result = await createOdooLead({
          firstName: lead.firstName,
          lastName: lead.lastName,
          email: lead.email,
          phone: lead.phone,
          country: lead.country,
          intent: lead.intent,
          lang: lead.lang,
          utmSource: lead.utmSource ?? undefined,
          utmMedium: lead.utmMedium ?? undefined,
          utmCampaign: lead.utmCampaign ?? undefined,
          referrer: lead.referrer ?? undefined,
        });

        await db
          .update(leads)
          .set({
            odooLeadId: String(result.leadId),
            odooSyncedAt: result.syncedAt,
            odooSyncError: null,
          })
          .where(eq(leads.id, input.leadId));

        return { success: true, odooLeadId: result.leadId };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        await db
          .update(leads)
          .set({
            odooSyncError: message,
          })
          .where(eq(leads.id, input.leadId));

        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `Odoo sync failed: ${message}`,
        });
      }
    }),
});
